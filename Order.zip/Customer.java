
public class Customer {
	String firstName;
	String lastName;
	int points;
	int rewardId = 0;
	static int counter = 0;
	
	public Customer(String firstName, String lastName, int points) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.points = points;
		
		counter++;
		
		rewardId = counter;
		
	}
	
	public void setFirstname(String firstName) {
		this.firstName = firstName;
	}
	
	public void setLastname(String lastName) {
		this.lastName = lastName;
	}
	
	public void updateRewards(int purchase) {
		points = purchase;
	}
	
	public void reedemRewards(int billAmount) {
		points = points - (billAmount * 100);
		System.out.println("Reward Points lefts: "+points);
	}
	
	public String toString() {
		String objectInfo = firstName +" "+lastName+" "+"Points: "+points+" Rewards ID: "+rewardId;
		return objectInfo; 
	}
	
	public static int customerCount() {
		
		return counter;
		
	}
	
}
