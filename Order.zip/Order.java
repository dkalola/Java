import java.util.Scanner;

public class Order {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int bill_amount = 0;
		int points = 0 ;
		
		Customer customer1 = new Customer("Divyanshu","Kalola",0);
		Customer customer2 = new Customer("Daniel","Haile",20000);
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Please enter the Bill Amount for Customer 1: ");
		bill_amount = scan.nextInt();
		customer1.updateRewards(bill_amount);
		
		System.out.println("Please enter the Bill Amount for Customer 2 (<200): ");
		bill_amount = scan.nextInt();
		customer2.reedemRewards(bill_amount);
		
		System.out.println("Customer count = "+ Customer.customerCount());
		
		System.out.println(customer1.toString());
		
	}

}
